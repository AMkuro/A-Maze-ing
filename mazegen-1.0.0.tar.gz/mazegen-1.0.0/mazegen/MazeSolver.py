from collections import deque
from typing import Deque
from .MazeModel import Maze, Wall, Pos, Solution


class MazeSolver:
    """Solve a maze using BFS."""

    directions = (
        (-1, 0, Wall.NORTH),
        (1, 0, Wall.SOUTH),
        (0, -1, Wall.WEST),
        (0, 1, Wall.EAST),
    )

    @staticmethod
    def solve(maze: "Maze") -> "Solution":
        """Find a shortest path from maze entry to exit.

        Args:
            maze: Maze to solve.

        Returns:
            Solution containing the path and N/E/W/S movement string.

        Raises:
            ValueError: If no path exists or path reconstruction fails.
        """
        start: Pos = maze.entry
        end: Pos = maze.exit

        came_from = MazeSolver._bfs(maze, start, end)

        if end not in came_from:
            raise ValueError("Maze has no solution")

        path = MazeSolver._reconstruct_path(came_from, start, end)
        news = MazeSolver._to_news_string(path)

        return Solution(path, news)

    @staticmethod
    def _bfs(
        maze: "Maze",
        start: Pos,
        end: Pos,
    ) -> dict[Pos, Pos | None]:
        """Run breadth-first search over open maze passages.

        Args:
            maze: Maze to traverse.
            start: Starting cell.
            end: Target cell.

        Returns:
            Mapping from each reached cell to its predecessor.
        """

        queue: Deque[Pos] = deque()
        queue.append((start[0], start[1]))
        grid = maze.grid
        came_from: dict[Pos, Pos | None] = {start: None}

        while queue:
            y, x = queue.popleft()

            if (y, x) == end:
                break

            for dy, dx, direction in MazeSolver.directions:
                ny, nx = y + dy, x + dx
                neighbor: Pos = (ny, nx)

                if neighbor in came_from:
                    continue

                if 0 <= ny < maze.height and 0 <= nx < maze.width:
                    if grid[y][x] & direction == direction:
                        continue

                    queue.append(neighbor)
                    came_from[neighbor] = (y, x)

        return came_from

    @staticmethod
    def _reconstruct_path(
        came_from: dict[Pos, Pos | None],
        start: Pos,
        end: Pos,
    ) -> list[Pos]:
        """Reconstruct a path from BFS predecessor data.

        Args:
            came_from: Mapping from reached cell to predecessor.
            start: Starting cell.
            end: Target cell.

        Returns:
            Ordered path from start to end.

        Raises:
            ValueError: If predecessor data is inconsistent.
        """

        path: list[Pos] = [end]
        curr: Pos = end

        while curr != start:
            prev = came_from[curr]
            if prev is None:
                raise ValueError("Invalid path data")
            path.append(prev)
            curr = prev

        path.reverse()
        return path

    @staticmethod
    def _to_news_string(path: list[Pos]) -> str:
        """Convert a path into a movement string.

        Args:
            path: Ordered cell positions.

        Returns:
            Movement string using N, E, W, and S.
        """
        moves: list[str] = []

        for i in range(1, len(path)):
            y1, x1 = path[i - 1]
            y2, x2 = path[i]

            dy = y2 - y1
            dx = x2 - x1

            if dy == -1:
                moves.append("N")
            elif dy == 1:
                moves.append("S")
            elif dx == 1:
                moves.append("E")
            elif dx == -1:
                moves.append("W")

        return "".join(moves)
